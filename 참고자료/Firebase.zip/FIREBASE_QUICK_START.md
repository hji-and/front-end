# Firebase 빠른 시작 가이드 🚀

이 파일은 Firebase 설정을 빠르게 시작할 수 있는 간단한 가이드입니다.
자세한 설명은 `FIREBASE_SETUP_GUIDE.md`를 참고하세요.

## 5분 안에 Firebase 설정하기

### 1️⃣ Firebase 프로젝트 생성
1. [Firebase Console](https://console.firebase.google.com) 접속
2. "프로젝트 추가" 클릭 → 프로젝트 이름 입력 → 생성

### 2️⃣ Firestore 활성화
1. 왼쪽 메뉴: "Firestore Database" 클릭
2. "데이터베이스 만들기" 클릭
3. "테스트 모드로 시작" 선택
4. 위치 선택 (asia-northeast3 권장) → 완료

### 3️⃣ 웹 앱 등록
1. ⚙️ 아이콘 → "프로젝트 설정"
2. "일반" 탭 → 하단 "내 앱" 섹션
3. </> (웹) 아이콘 클릭
4. 앱 닉네임 입력 → "앱 등록"
5. **Firebase 설정 정보 복사** (아래 형식)

```javascript
const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "프로젝트ID.firebaseapp.com",
  projectId: "프로젝트ID",
  storageBucket: "프로젝트ID.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc..."
};
```

### 4️⃣ .env 파일 생성
프로젝트 루트에 `.env` 파일을 만들고 아래 형식으로 입력:

```env
VITE_FIREBASE_API_KEY=복사한_apiKey_값
VITE_FIREBASE_AUTH_DOMAIN=복사한_authDomain_값
VITE_FIREBASE_PROJECT_ID=복사한_projectId_값
VITE_FIREBASE_STORAGE_BUCKET=복사한_storageBucket_값
VITE_FIREBASE_MESSAGING_SENDER_ID=복사한_messagingSenderId_값
VITE_FIREBASE_APP_ID=복사한_appId_값
```

**⚠️ 중요:** 따옴표 없이 값만 입력하세요!

### 5️⃣ 실행 및 테스트
```bash
npm install
npm run dev
```

브라우저에서 `http://localhost:5173` 접속 후 일기를 작성해보세요!

---

## 🔍 설정 확인 방법

일기를 작성한 후:
1. Firebase Console → Firestore Database → 데이터 탭
2. `diaries` 컬렉션이 생성되고 일기가 저장되었는지 확인

---

## ❓ 문제 해결

**데이터가 저장되지 않나요?**
- `.env` 파일이 프로젝트 루트에 있는지 확인
- `.env` 파일의 값이 올바른지 확인 (따옴표 없이)
- 브라우저 콘솔(F12)에서 오류 확인
- Firestore Database가 활성화되었는지 확인

**더 자세한 가이드가 필요하신가요?**
- `FIREBASE_SETUP_GUIDE.md` - 상세한 단계별 가이드
- `FIREBASE_CHECKLIST.md` - 체크리스트 형식 가이드

---

**준비 완료! 이제 Firebase에 일기를 저장할 수 있습니다! 🎉**

