# Firebase 설정 체크리스트 ✅

이 파일은 Firebase 설정 과정을 단계별로 확인할 수 있는 체크리스트입니다.

## 📋 Firebase Console에서 해야 할 일

### 1단계: 프로젝트 생성
- [ ] [Firebase Console](https://console.firebase.google.com) 접속
- [ ] Google 계정으로 로그인
- [ ] "프로젝트 추가" 버튼 클릭
- [ ] 프로젝트 이름 입력 (예: "my-diary-app")
- [ ] Google Analytics 설정 (선택사항)
- [ ] 프로젝트 생성 완료 대기

### 2단계: Firestore Database 활성화
- [ ] 왼쪽 메뉴에서 "Firestore Database" 클릭
- [ ] "데이터베이스 만들기" 버튼 클릭
- [ ] "테스트 모드로 시작" 선택 (개발용)
- [ ] 데이터베이스 위치 선택 (asia-northeast3 권장)
- [ ] 데이터베이스 생성 완료 대기

### 3단계: 웹 앱 등록 및 설정 정보 복사
- [ ] ⚙️ 아이콘 클릭 > "프로젝트 설정" 선택
- [ ] "일반" 탭 확인
- [ ] "내 앱" 섹션에서 </> (웹) 아이콘 클릭
- [ ] 앱 닉네임 입력
- [ ] "앱 등록" 버튼 클릭
- [ ] Firebase 설정 정보 확인 및 복사

**복사해야 할 정보:**
```
apiKey: "________________"
authDomain: "________________"
projectId: "________________"
storageBucket: "________________"
messagingSenderId: "________________"
appId: "________________"
```

### 4단계: 보안 규칙 확인 (선택사항)
- [ ] "Firestore Database" > "규칙" 탭 클릭
- [ ] 현재 규칙 확인
- [ ] 테스트 모드인 경우: `allow read, write: if true;` 확인
- [ ] 필요시 규칙 수정 후 "게시" 클릭

---

## 💻 로컬 프로젝트에서 해야 할 일

### 5단계: 환경 변수 파일 생성
- [ ] 프로젝트 루트에 `.env` 파일 생성
- [ ] `env.example` 파일 참고하여 형식 확인

### 6단계: Firebase 설정 정보 입력
`.env` 파일에 다음 형식으로 입력:

```env
VITE_FIREBASE_API_KEY=여기에_apiKey_값_입력
VITE_FIREBASE_AUTH_DOMAIN=여기에_authDomain_값_입력
VITE_FIREBASE_PROJECT_ID=여기에_projectId_값_입력
VITE_FIREBASE_STORAGE_BUCKET=여기에_storageBucket_값_입력
VITE_FIREBASE_MESSAGING_SENDER_ID=여기에_messagingSenderId_값_입력
VITE_FIREBASE_APP_ID=여기에_appId_값_입력
```

**⚠️ 주의사항:**
- 각 값 앞뒤에 따옴표나 공백 없이 입력
- 실제 Firebase에서 받은 값으로 교체
- `.env` 파일은 Git에 커밋하지 않기 (이미 .gitignore에 추가됨)

### 7단계: 의존성 설치 및 실행
- [ ] 터미널에서 `npm install` 실행
- [ ] `npm run dev` 실행
- [ ] 브라우저에서 `http://localhost:5173` 접속

### 8단계: 테스트
- [ ] 일기 작성 폼에 내용 입력
- [ ] "저장하기" 버튼 클릭
- [ ] Firebase Console > Firestore Database > 데이터 탭에서 저장된 일기 확인
- [ ] 일기 목록에 새 일기가 표시되는지 확인
- [ ] 일기 수정 기능 테스트
- [ ] 일기 삭제 기능 테스트

---

## 🔍 문제 해결 체크리스트

문제가 발생한 경우 다음을 확인하세요:

### 데이터가 저장되지 않을 때
- [ ] `.env` 파일이 프로젝트 루트에 있는지 확인
- [ ] `.env` 파일의 모든 값이 올바르게 입력되었는지 확인
- [ ] Firebase Console에서 Firestore Database가 활성화되었는지 확인
- [ ] 브라우저 콘솔(F12)에서 오류 메시지 확인
- [ ] Firestore 보안 규칙이 올바르게 설정되었는지 확인

### 개발 서버가 실행되지 않을 때
- [ ] `npm install`이 완료되었는지 확인
- [ ] Node.js가 설치되어 있는지 확인 (v16 이상 권장)
- [ ] 포트 5173이 사용 중이 아닌지 확인

### Firebase 연결 오류가 발생할 때
- [ ] 인터넷 연결 확인
- [ ] Firebase 프로젝트가 정상적으로 생성되었는지 확인
- [ ] `.env` 파일의 값이 Firebase Console의 설정과 일치하는지 확인
- [ ] 브라우저 콘솔의 정확한 오류 메시지 확인

---

## 📝 참고 사항

### Firebase 무료 플랜 제한
- 일일 읽기: 50,000회
- 일일 쓰기: 20,000회
- 일일 삭제: 20,000회
- 저장 공간: 1GB

### 유용한 링크
- [Firebase Console](https://console.firebase.google.com)
- [Firebase 문서](https://firebase.google.com/docs)
- [Firestore 문서](https://firebase.google.com/docs/firestore)

---

## ✅ 최종 확인

모든 단계를 완료했다면:
- [ ] 일기를 작성하고 Firebase에 저장되는지 확인
- [ ] Firebase Console에서 데이터가 표시되는지 확인
- [ ] 페이지를 새로고침해도 데이터가 유지되는지 확인
- [ ] 다른 기기에서도 접근 가능한지 확인 (배포 후)

**축하합니다! 🎉 Firebase 연동이 완료되었습니다!**

