# 나의 다이어리 앱 📔

React와 Firebase Firestore를 사용한 다이어리 애플리케이션입니다.

## 기능

- ✏️ 일기 작성 및 수정
- 📅 날짜별 일기 관리
- 😊 기분 이모지 선택
- 🗑️ 일기 삭제
- ☁️ Firebase Firestore에 저장 (실제 클라우드 데이터베이스)
- 📱 반응형 디자인

## Firebase 설정

Firebase 설정에 대한 자세한 가이드는 다음 파일들을 참고하세요:

- 📖 **[FIREBASE_SETUP_GUIDE.md](./FIREBASE_SETUP_GUIDE.md)** - 상세한 단계별 설정 가이드
- ✅ **[FIREBASE_CHECKLIST.md](./FIREBASE_CHECKLIST.md)** - 체크리스트 형식의 설정 가이드
- 🚀 **[FIREBASE_QUICK_START.md](./FIREBASE_QUICK_START.md)** - 빠른 시작 가이드 (5분)

### 빠른 요약

1. [Firebase Console](https://console.firebase.google.com)에서 프로젝트 생성
2. Firestore Database 활성화 (테스트 모드로 시작)
3. 웹 앱 등록 및 설정 정보 복사
4. 프로젝트 루트에 `.env` 파일 생성 및 Firebase 설정 정보 입력

자세한 내용은 위의 가이드 파일들을 참고하세요.

## 설치 및 실행

1. 의존성 설치:
```bash
npm install
```

2. `.env` 파일을 생성하고 Firebase 설정 정보를 입력합니다 (위의 Firebase 설정 참조).

3. 개발 서버 실행:
```bash
npm run dev
```

4. 브라우저에서 `http://localhost:5173` 접속

## 빌드

프로덕션 빌드:
```bash
npm run build
```

빌드 미리보기:
```bash
npm run preview
```

## 사용 방법

1. **일기 작성**: 왼쪽 폼에서 날짜, 기분, 제목, 내용을 입력하고 "저장하기" 버튼을 클릭합니다.
2. **일기 수정**: 일기 항목의 ✏️ 버튼을 클릭하여 수정합니다.
3. **일기 삭제**: 일기 항목의 🗑️ 버튼을 클릭하여 삭제합니다.

모든 일기는 Firebase Firestore에 저장되어 어느 기기에서든 접근할 수 있으며, 페이지를 새로고침해도 유지됩니다.

