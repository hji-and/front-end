import { initializeApp } from 'firebase/app'
import { getFirestore } from 'firebase/firestore'

// Firebase 설정
// 환경 변수에서 가져오거나 직접 입력하세요
const firebaseConfig = {
    apiKey: "AIzaSyBaH53DBUnuL-s2aV23J5vQSFhyAwWXp9E",
    authDomain: "my-diary-app-ad43f.firebaseapp.com",
    projectId: "my-diary-app-ad43f",
    storageBucket: "my-diary-app-ad43f.firebasestorage.app",
    messagingSenderId: "971833843808",
    appId: "1:971833843808:web:2c47ea3a5f4f834627e305",
    measurementId: "G-V99CLTXCPY"
  };

// Firebase 초기화
const app = initializeApp(firebaseConfig)

// Firestore 초기화
export const db = getFirestore(app)
export default app

