import {
  collection,
  addDoc,
  getDocs,
  doc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  Timestamp
} from 'firebase/firestore'
import { db } from './config'

const DIARIES_COLLECTION = 'diaries'

// 모든 일기 가져오기
export const getDiaries = async () => {
  try {
    const q = query(collection(db, DIARIES_COLLECTION), orderBy('date', 'desc'))
    const querySnapshot = await getDocs(q)
    const diaries = []
    querySnapshot.forEach((doc) => {
      diaries.push({
        id: doc.id,
        ...doc.data()
      })
    })
    return diaries
  } catch (error) {
    console.error('일기 가져오기 오류:', error)
    throw error
  }
}

// 새 일기 추가
export const addDiary = async (diary) => {
  try {
    const docRef = await addDoc(collection(db, DIARIES_COLLECTION), {
      title: diary.title,
      content: diary.content,
      date: diary.date,
      mood: diary.mood,
      createdAt: Timestamp.now()
    })
    return docRef.id
  } catch (error) {
    console.error('일기 추가 오류:', error)
    throw error
  }
}

// 일기 수정
export const updateDiary = async (id, diary) => {
  try {
    const diaryRef = doc(db, DIARIES_COLLECTION, id)
    await updateDoc(diaryRef, {
      title: diary.title,
      content: diary.content,
      date: diary.date,
      mood: diary.mood,
      updatedAt: Timestamp.now()
    })
  } catch (error) {
    console.error('일기 수정 오류:', error)
    throw error
  }
}

// 일기 삭제
export const deleteDiary = async (id) => {
  try {
    await deleteDoc(doc(db, DIARIES_COLLECTION, id))
  } catch (error) {
    console.error('일기 삭제 오류:', error)
    throw error
  }
}

