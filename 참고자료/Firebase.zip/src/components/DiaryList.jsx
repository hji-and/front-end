import DiaryItem from './DiaryItem'
import './DiaryList.css'

function DiaryList({ diaries, onDelete, onEdit }) {
  if (diaries.length === 0) {
    return (
      <div className="diary-list-empty">
        <p>📝 아직 작성된 일기가 없습니다.</p>
        <p>첫 번째 일기를 작성해보세요!</p>
      </div>
    )
  }

  // 날짜순으로 정렬 (최신순)
  const sortedDiaries = [...diaries].sort((a, b) => {
    const dateA = new Date(a.date || a.createdAt)
    const dateB = new Date(b.date || b.createdAt)
    return dateB - dateA
  })

  return (
    <div className="diary-list-container">
      <h2>일기 목록 ({diaries.length}개)</h2>
      <div className="diary-list">
        {sortedDiaries.map((diary) => (
          <DiaryItem
            key={diary.id}
            diary={diary}
            onDelete={onDelete}
            onEdit={onEdit}
          />
        ))}
      </div>
    </div>
  )
}

export default DiaryList

