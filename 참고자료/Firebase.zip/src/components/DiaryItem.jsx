import './DiaryItem.css'

function DiaryItem({ diary, onDelete, onEdit }) {
  const formatDate = (dateString) => {
    if (!dateString) return ''
    const date = new Date(dateString)
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const day = String(date.getDate()).padStart(2, '0')
    const weekdays = ['일', '월', '화', '수', '목', '금', '토']
    const weekday = weekdays[date.getDay()]
    return `${year}.${month}.${day} (${weekday})`
  }

  return (
    <div className="diary-item">
      <div className="diary-item-header">
        <div className="diary-item-date-mood">
          <span className="diary-mood">{diary.mood || '😊'}</span>
          <span className="diary-date">{formatDate(diary.date || diary.createdAt)}</span>
        </div>
        <div className="diary-item-actions">
          <button 
            className="btn-edit" 
            onClick={() => onEdit(diary.id)}
            title="수정"
          >
            ✏️
          </button>
          <button 
            className="btn-delete" 
            onClick={() => onDelete(diary.id)}
            title="삭제"
          >
            🗑️
          </button>
        </div>
      </div>
      <h3 className="diary-item-title">{diary.title}</h3>
      <p className="diary-item-content">{diary.content}</p>
    </div>
  )
}

export default DiaryItem

