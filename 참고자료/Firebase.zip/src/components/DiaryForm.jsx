import { useState, useEffect } from 'react'
import './DiaryForm.css'

function DiaryForm({ onSave, editingDiary, onCancel }) {
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [date, setDate] = useState(new Date().toISOString().split('T')[0])
  const [mood, setMood] = useState('😊')

  useEffect(() => {
    if (editingDiary) {
      setTitle(editingDiary.title || '')
      setContent(editingDiary.content || '')
      setDate(editingDiary.date || new Date().toISOString().split('T')[0])
      setMood(editingDiary.mood || '😊')
    } else {
      resetForm()
    }
  }, [editingDiary])

  const resetForm = () => {
    setTitle('')
    setContent('')
    setDate(new Date().toISOString().split('T')[0])
    setMood('😊')
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!title.trim() || !content.trim()) {
      alert('제목과 내용을 입력해주세요.')
      return
    }

    onSave({
      title: title.trim(),
      content: content.trim(),
      date,
      mood
    })
    resetForm()
  }

  const moods = ['😊', '😢', '😡', '😴', '🤔', '😍', '😎', '🥳']

  return (
    <div className="diary-form-container">
      <h2>{editingDiary ? '일기 수정' : '새 일기 작성'}</h2>
      <form onSubmit={handleSubmit} className="diary-form">
        <div className="form-group">
          <label htmlFor="date">날짜</label>
          <input
            type="date"
            id="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="mood">오늘의 기분</label>
          <div className="mood-selector">
            {moods.map((m) => (
              <button
                key={m}
                type="button"
                className={`mood-btn ${mood === m ? 'active' : ''}`}
                onClick={() => setMood(m)}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="title">제목</label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="오늘의 제목을 입력하세요"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="content">내용</label>
          <textarea
            id="content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="오늘 하루는 어땠나요?"
            rows="8"
            required
          />
        </div>

        <div className="form-actions">
          {editingDiary && (
            <button type="button" onClick={onCancel} className="btn btn-cancel">
              취소
            </button>
          )}
          <button type="submit" className="btn btn-submit">
            {editingDiary ? '수정하기' : '저장하기'}
          </button>
        </div>
      </form>
    </div>
  )
}

export default DiaryForm

