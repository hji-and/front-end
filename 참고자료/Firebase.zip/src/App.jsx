import { useState, useEffect } from 'react'
import DiaryList from './components/DiaryList'
import DiaryForm from './components/DiaryForm'
import { getDiaries, addDiary, updateDiary, deleteDiary as deleteDiaryFromFirebase } from './firebase/diaryService'
import './App.css'

function App() {
  const [diaries, setDiaries] = useState([])
  const [editingId, setEditingId] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  // Firebase에서 일기 불러오기
  useEffect(() => {
    loadDiaries()
  }, [])

  const loadDiaries = async () => {
    try {
      setLoading(true)
      setError(null)
      const fetchedDiaries = await getDiaries()
      // Firestore Timestamp를 문자열로 변환
      const formattedDiaries = fetchedDiaries.map(diary => ({
        ...diary,
        createdAt: diary.createdAt?.toDate?.()?.toISOString() || diary.createdAt,
        updatedAt: diary.updatedAt?.toDate?.()?.toISOString() || diary.updatedAt
      }))
      setDiaries(formattedDiaries)
    } catch (err) {
      console.error('일기 로드 오류:', err)
      setError('일기를 불러오는 중 오류가 발생했습니다.')
    } finally {
      setLoading(false)
    }
  }

  // 일기 저장
  const saveDiary = async (diary) => {
    try {
      setError(null)
      if (editingId) {
        // 수정 모드
        await updateDiary(editingId, diary)
        setEditingId(null)
      } else {
        // 새 일기 추가
        await addDiary(diary)
      }
      // 일기 목록 새로고침
      await loadDiaries()
    } catch (err) {
      console.error('일기 저장 오류:', err)
      setError('일기를 저장하는 중 오류가 발생했습니다.')
      alert('일기 저장에 실패했습니다. 다시 시도해주세요.')
    }
  }

  // 일기 삭제
  const deleteDiary = async (id) => {
    if (window.confirm('정말 삭제하시겠습니까?')) {
      try {
        setError(null)
        await deleteDiaryFromFirebase(id)
        // 일기 목록 새로고침
        await loadDiaries()
      } catch (err) {
        console.error('일기 삭제 오류:', err)
        setError('일기를 삭제하는 중 오류가 발생했습니다.')
        alert('일기 삭제에 실패했습니다. 다시 시도해주세요.')
      }
    }
  }

  // 일기 수정 시작
  const startEdit = (id) => {
    setEditingId(id)
  }

  // 수정 취소
  const cancelEdit = () => {
    setEditingId(null)
  }

  return (
    <div className="app">
      <header className="app-header">
        <h1>📔 나의 다이어리</h1>
        <p>오늘의 하루를 기록해보세요</p>
        {error && <div className="error-message">{error}</div>}
      </header>
      <main className="app-main">
        {loading ? (
          <div className="loading">일기를 불러오는 중...</div>
        ) : (
          <>
            <DiaryForm 
              onSave={saveDiary}
              editingDiary={editingId ? diaries.find(d => d.id === editingId) : null}
              onCancel={cancelEdit}
            />
            <DiaryList 
              diaries={diaries}
              onDelete={deleteDiary}
              onEdit={startEdit}
            />
          </>
        )}
      </main>
    </div>
  )
}

export default App

