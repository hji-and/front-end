# Firebase 설정 가이드 🔥

이 문서는 다이어리 앱을 Firebase에 연결하기 위한 단계별 가이드를 제공합니다.

## 목차
1. [Firebase 프로젝트 생성](#1-firebase-프로젝트-생성)
2. [Firestore Database 활성화](#2-firestore-database-활성화)
3. [웹 앱 등록](#3-웹-앱-등록)
4. [환경 변수 설정](#4-환경-변수-설정)
5. [보안 규칙 설정](#5-보안-규칙-설정-선택사항)

---

## 1. Firebase 프로젝트 생성

### 1.1 Firebase Console 접속
1. 웹 브라우저에서 [Firebase Console](https://console.firebase.google.com)에 접속합니다.
2. Google 계정으로 로그인합니다.

### 1.2 새 프로젝트 만들기
1. 화면 상단의 **"프로젝트 추가"** 또는 **"Add project"** 버튼을 클릭합니다.
2. **프로젝트 이름**을 입력합니다 (예: "my-diary-app")
3. **계속** 버튼을 클릭합니다.

### 1.3 Google Analytics 설정 (선택사항)
1. Google Analytics 사용 여부를 선택합니다.
   - 개발 단계에서는 **"지금은 사용 안 함"**을 선택해도 됩니다.
   - 프로덕션 환경에서는 Analytics를 활성화하는 것을 권장합니다.
2. **프로젝트 만들기** 버튼을 클릭합니다.
3. 프로젝트 생성이 완료될 때까지 몇 초 기다립니다.

---

## 2. Firestore Database 활성화

### 2.1 Firestore Database 메뉴 접속
1. Firebase Console 왼쪽 메뉴에서 **"Firestore Database"** 또는 **"빌드" > "Firestore Database"**를 클릭합니다.

### 2.2 데이터베이스 만들기
1. **"데이터베이스 만들기"** 또는 **"Create database"** 버튼을 클릭합니다.

### 2.3 보안 규칙 선택
개발 단계에서는 **"테스트 모드로 시작"**을 선택합니다.
- ⚠️ **주의**: 테스트 모드는 30일 후에 만료되며, 모든 사용자가 읽기/쓰기 권한을 가집니다.
- 프로덕션 환경에서는 나중에 보안 규칙을 설정해야 합니다.

### 2.4 위치 선택
1. 데이터베이스 위치를 선택합니다.
   - 한국 사용자: **asia-northeast3 (Seoul)** 권장
   - 위치 선택 후 **"완료"** 또는 **"Done"** 클릭
2. 데이터베이스 생성이 완료될 때까지 몇 분이 소요될 수 있습니다.

---

## 3. 웹 앱 등록

### 3.1 프로젝트 설정 접속
1. Firebase Console 왼쪽 상단의 ⚙️ 아이콘을 클릭합니다.
2. **"프로젝트 설정"** 또는 **"Project settings"**를 선택합니다.

### 3.2 웹 앱 추가
1. 설정 페이지에서 **"일반"** 탭이 선택되어 있는지 확인합니다.
2. 페이지 하단의 **"내 앱"** 섹션에서 **</>** (웹) 아이콘을 클릭합니다.

### 3.3 앱 등록 정보 입력
1. **앱 닉네임**을 입력합니다 (예: "My Diary App")
2. **"Firebase Hosting도 설정"** 체크박스는 선택하지 않아도 됩니다.
3. **"앱 등록"** 또는 **"Register app"** 버튼을 클릭합니다.

### 3.4 Firebase 설정 정보 복사
다음과 같은 Firebase 설정 정보가 표시됩니다:

```javascript
const firebaseConfig = {
  apiKey: "AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  authDomain: "my-diary-app.firebaseapp.com",
  projectId: "my-diary-app",
  storageBucket: "my-diary-app.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef1234567890"
};
```

이 정보를 복사하거나, 아래 단계에서 개별적으로 복사할 수 있습니다.

---

## 4. 환경 변수 설정

### 4.1 .env 파일 생성
프로젝트 루트 디렉토리(`package.json`이 있는 폴더)에 `.env` 파일을 생성합니다.

### 4.2 Firebase 설정 정보 입력
`.env` 파일에 다음 형식으로 Firebase 설정 정보를 입력합니다:

```env
VITE_FIREBASE_API_KEY=AIzaSyXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
VITE_FIREBASE_AUTH_DOMAIN=my-diary-app.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=my-diary-app
VITE_FIREBASE_STORAGE_BUCKET=my-diary-app.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789012
VITE_FIREBASE_APP_ID=1:123456789012:web:abcdef1234567890
```

**⚠️ 중요 사항:**
- `env.example` 파일의 예시를 참고하되, 실제 Firebase에서 받은 값으로 교체해야 합니다.
- `.env` 파일은 절대 Git에 커밋하지 마세요! (이미 `.gitignore`에 추가되어 있습니다)
- 각 값 앞뒤에 따옴표(`"`)나 공백이 없어야 합니다.

### 4.3 설정 확인
각 환경 변수가 올바르게 설정되었는지 확인:
- `VITE_FIREBASE_API_KEY`: Firebase API 키
- `VITE_FIREBASE_AUTH_DOMAIN`: `프로젝트ID.firebaseapp.com` 형식
- `VITE_FIREBASE_PROJECT_ID`: Firebase 프로젝트 ID
- `VITE_FIREBASE_STORAGE_BUCKET`: `프로젝트ID.appspot.com` 형식
- `VITE_FIREBASE_MESSAGING_SENDER_ID`: 숫자로 된 Sender ID
- `VITE_FIREBASE_APP_ID`: `1:숫자:web:문자열` 형식

---

## 5. 보안 규칙 설정 (선택사항)

### 5.1 Firestore 보안 규칙 접속
1. Firebase Console에서 **"Firestore Database"** 메뉴로 이동합니다.
2. 상단 탭에서 **"규칙"** 또는 **"Rules"** 탭을 클릭합니다.

### 5.2 개발용 규칙 (테스트 모드)
개발 중에는 다음 규칙을 사용할 수 있습니다:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

⚠️ **경고**: 이 규칙은 모든 사용자에게 읽기/쓰기 권한을 부여합니다. 프로덕션 환경에서는 사용하지 마세요!

### 5.3 프로덕션용 규칙 (권장)
실제 서비스에서는 인증을 추가하거나 더 엄격한 규칙을 설정해야 합니다:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /diaries/{diaryId} {
      // 인증된 사용자만 읽기/쓰기 가능
      allow read, write: if request.auth != null;
      
      // 또는 모든 사용자가 자신의 일기만 접근 가능
      // allow read, write: if request.auth != null && request.auth.uid == resource.data.userId;
    }
  }
}
```

### 5.4 규칙 게시
1. 규칙을 작성한 후 **"게시"** 또는 **"Publish"** 버튼을 클릭합니다.

---

## 6. 앱 테스트

### 6.1 개발 서버 실행
터미널에서 다음 명령어를 실행합니다:

```bash
npm install
npm run dev
```

### 6.2 브라우저에서 확인
1. 브라우저에서 `http://localhost:5173`에 접속합니다.
2. 일기를 작성하고 저장합니다.
3. Firebase Console의 **"Firestore Database" > "데이터"** 탭에서 저장된 일기를 확인할 수 있습니다.

### 6.3 문제 해결
- **오류 발생 시**: 브라우저 콘솔(F12)에서 오류 메시지를 확인합니다.
- **데이터가 저장되지 않을 때**: 
  - `.env` 파일의 값이 올바른지 확인
  - Firestore Database가 활성화되었는지 확인
  - 보안 규칙이 올바르게 설정되었는지 확인

---

## 7. 추가 정보

### 7.1 Firebase 무료 플랜 제한
- Firestore: 일일 읽기 50,000회, 쓰기 20,000회, 삭제 20,000회
- 저장 공간: 1GB
- 대부분의 개인 프로젝트에는 충분합니다.

### 7.2 유용한 링크
- [Firebase 공식 문서](https://firebase.google.com/docs)
- [Firestore 문서](https://firebase.google.com/docs/firestore)
- [Firebase Console](https://console.firebase.google.com)

### 7.3 다음 단계 (선택사항)
- Firebase Authentication 추가 (사용자별 일기 관리)
- Firebase Storage 추가 (이미지 업로드)
- Firebase Hosting으로 배포

---

## 체크리스트 ✅

Firebase 설정이 완료되었는지 확인하세요:

- [ ] Firebase 프로젝트 생성 완료
- [ ] Firestore Database 활성화 완료
- [ ] 웹 앱 등록 완료
- [ ] `.env` 파일 생성 및 설정 정보 입력 완료
- [ ] 개발 서버 실행 및 테스트 완료
- [ ] Firestore에 데이터가 저장되는지 확인 완료

---

**문제가 발생하면 브라우저 콘솔의 오류 메시지를 확인하거나, Firebase Console에서 설정을 다시 점검해보세요!**

